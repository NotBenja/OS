#define N_EST 10

void initReservar();
void cleanReservar();
void liberar(int e, int k);
int reservar(int k);
